
import json
from pathlib import Path

import streamlit as st
import networkx as nx
from pyvis.network import Network
import streamlit.components.v1 as components

FILE = Path("/content/mindmesh_data.json")

DEFAULT = {
    "notes": [
        {"id": "1", "title": "Learning",
         "content": "Turn ideas into practical skills.",
         "tags": ["growth", "skills"]},
        {"id": "2", "title": "Projects",
         "content": "Build small projects to learn by doing.",
         "tags": ["building", "skills"]},
        {"id": "3", "title": "Creativity",
         "content": "Collect interesting ideas.",
         "tags": ["ideas"]}
    ],
    "links": [
        {"source": "1", "target": "2"},
        {"source": "2", "target": "3"}
    ]
}

st.set_page_config(page_title="MindMesh", page_icon="🕸️",
                   layout="wide")

if "data" not in st.session_state:
    if FILE.exists():
        try:
            st.session_state.data = json.loads(
                FILE.read_text(encoding="utf-8"))
        except Exception:
            st.session_state.data = DEFAULT.copy()
    else:
        st.session_state.data = json.loads(json.dumps(DEFAULT))

data = st.session_state.data

def save():
    FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

st.title("🕸️ MindMesh")
st.caption("Your personal knowledge graph")
st.write("Create notes, connect ideas, and explore your knowledge.")

notes = data["notes"]
links = data["links"]
by_id = {n["id"]: n for n in notes}

graph_tab, notes_tab, connect_tab, export_tab = st.tabs([
    "🌐 Graph", "📝 Notes", "🔗 Connections", "📦 Export"
])

with graph_tab:
    query = st.text_input("Search your knowledge").lower().strip()
    tag = st.text_input("Filter by tag").lower().strip()

    visible = []
    for n in notes:
        text = (n["title"] + " " + n["content"] +
                " " + " ".join(n["tags"])).lower()
        if query and query not in text:
            continue
        if tag and tag not in [t.lower() for t in n["tags"]]:
            continue
        visible.append(n)

    if visible:
        ids = {n["id"] for n in visible}
        net = Network(height="520px", width="100%",
                      bgcolor="#101526", font_color="white")
        net.barnes_hut()

        for n in visible:
            net.add_node(
                n["id"],
                label=n["title"],
                title=n["content"] + "\\nTags: " +
                      ", ".join(n["tags"]),
                color="#8da9ff",
                size=24
            )

        for edge in links:
            if edge["source"] in ids and edge["target"] in ids:
                net.add_edge(edge["source"], edge["target"])

        graph_file = "/tmp/mindmesh.html"
        net.save_graph(graph_file)
        components.html(
            Path(graph_file).read_text(encoding="utf-8"),
            height=540
        )
    else:
        st.info("No matching notes.")

with notes_tab:
    st.subheader("Create a note")

    with st.form("create"):
        title = st.text_input("Title")
        content = st.text_area("Content")
        tags = st.text_input("Tags, separated by commas")
        submit = st.form_submit_button("Add note")

    if submit:
        if title.strip():
            used = {n["id"] for n in notes}
            number = 1
            while f"note{number}" in used:
                number += 1

            notes.append({
                "id": f"note{number}",
                "title": title.strip(),
                "content": content.strip(),
                "tags": [t.strip() for t in tags.split(",")
                         if t.strip()]
            })
            save()
            st.rerun()
        else:
            st.error("Please enter a title.")

    st.divider()
    st.subheader("Edit your notes")

    for n in list(notes):
        with st.expander(n["title"]):
            with st.form("edit_" + n["id"]):
                new_title = st.text_input("Title", value=n["title"])
                new_content = st.text_area(
                    "Content", value=n["content"])
                new_tags = st.text_input(
                    "Tags", value=", ".join(n["tags"]))
                c1, c2 = st.columns(2)
                update = c1.form_submit_button("Save")
                delete = c2.form_submit_button("Delete")

            if update:
                if new_title.strip():
                    n["title"] = new_title.strip()
                    n["content"] = new_content.strip()
                    n["tags"] = [
                        t.strip() for t in new_tags.split(",")
                        if t.strip()
                    ]
                    save()
                    st.rerun()
                else:
                    st.error("Title cannot be empty.")

            if delete:
                data["notes"] = [
                    x for x in notes if x["id"] != n["id"]]
                data["links"] = [
                    e for e in links
                    if e["source"] != n["id"]
                    and e["target"] != n["id"]
                ]
                save()
                st.rerun()

with connect_tab:
    if len(notes) < 2:
        st.info("Add at least two notes first.")
    else:
        labels = {n["id"]: n["title"] for n in notes}

        with st.form("connect"):
            source = st.selectbox(
                "First idea", list(labels),
                format_func=lambda x: labels[x])
            choices = [
                n["id"] for n in notes if n["id"] != source]
            target = st.selectbox(
                "Related idea", choices,
                format_func=lambda x: labels[x])
            submit_link = st.form_submit_button("Connect ideas")

        if submit_link:
            exists = any(
                {e["source"], e["target"]} == {source, target}
                for e in links
            )
            if exists:
                st.warning("These ideas are already connected.")
            else:
                links.append({
                    "source": source, "target": target})
                save()
                st.rerun()

    st.subheader("Current connections")
    for i, edge in enumerate(list(links)):
        a = by_id.get(edge["source"], {}).get(
            "title", edge["source"])
        b = by_id.get(edge["target"], {}).get(
            "title", edge["target"])
        st.write(f"**{a}** ↔ **{b}**")
        if st.button("Remove connection", key=f"remove{i}"):
            links.remove(edge)
            save()
            st.rerun()

with export_tab:
    st.subheader("Back up your knowledge")

    st.download_button(
        "Download JSON backup",
        json.dumps(data, indent=2),
        file_name="mindmesh_backup.json",
        mime="application/json"
    )

    markdown = "# MindMesh Notes\\n\\n"
    for n in notes:
        markdown += (
            f"## {n['title']}\\n\\n{n['content']}\\n\\n"
            f"Tags: {', '.join(n['tags'])}\\n\\n"
        )

    st.download_button(
        "Download Markdown",
        markdown,
        file_name="mindmesh_notes.md",
        mime="text/markdown"
    )

    uploaded = st.file_uploader("Restore JSON backup", type="json")
    if uploaded and st.button("Import backup"):
        try:
            restored = json.loads(uploaded.getvalue())
            assert isinstance(restored["notes"], list)
            assert isinstance(restored["links"], list)
            ids = {n["id"] for n in restored["notes"]}
            assert all(
                e["source"] in ids and e["target"] in ids
                for e in restored["links"]
            )
            data.clear()
            data.update(restored)
            save()
            st.rerun()
        except Exception:
            st.error("That backup is invalid.")

st.caption("MindMesh · Python · Streamlit · NetworkX · PyVis")
