# MindMesh 🧠

**A personal knowledge graph for connecting ideas, notes, and projects.**

MindMesh helps you:
- Create, edit, and organize notes
- Add tags and search your knowledge
- Connect related ideas in an interactive graph
- Export your notes as JSON backups or Markdown
- Import a JSON backup

## Features

- Interactive knowledge graph
- Notes and connections
- Tag-based organization
- Search and filtering
- JSON import/export
- Markdown export

## Built with

- Python
- Streamlit
- PyVis
- NetworkX

## Run locally

1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:

   `pip install -r requirements.txt`

4. Start the app:

   `streamlit run mindmesh_app.py`

5. Open the local URL shown by Streamlit.

## Data and privacy

MindMesh currently stores data in a local JSON file when running in its current environment. In temporary environments such as Google Colab, files may disappear when the runtime resets. Export and save regular backups.

Before deploying publicly, review the app's storage and privacy behavior.

## Project status

Initial prototype — built with AI assistance. Further improvements may include persistent storage, mobile-friendly design, and deployment.

## License

MIT — see [LICENSE](LICENSE).
